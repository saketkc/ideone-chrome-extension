ideone-chrome-extension
=======================

A chrome extension that allows running code on ideone simply by selecting the text in a browser window